<?php
global $Wcms;

$visa = $_POST['visa'];

file_puts_contents('center.name', $visa);
?>
